

<div class="header">
		<div class="container">
			<div class="header-grid">
				
				<div class="header-grid-right animated wow slideInRight" data-wow-delay=".5s">
					<ul class="social-icons">
						<li><a href="https://www.facebook.com/" class="facebook"></a></li>
						<li><a href="https://twitter.com/login" class="twitter"></a></li>
						<li><a href="https://www.google.com/" class="g"></a></li>
						<li><a href="https://www.instagram.com" class="instagram"></a></li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
			
			<div class="logo-nav">
				<div class="logo-nav-left animated wow zoomIn" data-wow-delay=".5s">
					<h1><a href="home.php"><h2>makeyourcomputer.com</h2><span>Shop anywhere</span></a></h1>
					
				</div>
				<div class="logo-nav-left1">
					<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header nav_2">
						<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div> 
					<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
						<ul class="nav navbar-nav">
                       <li class="active"><a href="home.php" class="act">Home</a></li>
                       

                       
                       <li class="active"><a href="view_job.php">My Job</a></li>
                       
                       <li class="active"><a href="completed_job.php">Completed Job</a></li>
                        
                     <li class="active"><a href="../login.php" class="act">Logout</a></li>

							
<!--							<li><a href="">Short Codes</a></li>
							<li><a href="mail.html">Mail Us</a></li>-->
						</ul>
						<!--<li><form action="search1.php" method="post">
                     	 <tr>
                       <td></td>
                       <td><input type="text" name="name"></td>
                       <td><input type="Submit" name="submit" value="Search"></td>
                      
                       
                       </tr>-->
                      </li>	
					</div>
					</nav>
				</div>
				
		</div>
	</div>