<?php
include '../connection.php';
if(isset($_POST['job'])) 
{
$job=$_POST["jobs"];
$allo = $_POST["allo"];

$sql2="UPDATE allocate SET stat='$job' WHERE a_id='$allo' ";
mysqli_query($con,$sql2);



echo"<script>alert('Update Sucessfull');window.location='view_job.php';</script>";
}
else{

	$de=$_POST["de"];
$order = $_POST["order"];

$sql2="UPDATE order1 SET deliv='$de' WHERE oid='$order' ";
mysqli_query($con,$sql2);



echo"<script>alert('Update Sucessfull');window.location='view_job.php';</script>";

}
?>




