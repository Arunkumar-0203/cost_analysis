<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<?php
session_start();
if($_SESSION)
{


?>
<html>
<head>
<title>Computer assembly</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Best Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- timer -->
<link rel="stylesheet" href="css/jquery.countdown.css" />
<!-- //timer -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
	
<body>
<!-- header -->
	<?php
	include 'adminheader.php';
	?>
<!-- //header -->
<!-- banner -->
	<div class="banner">
		<div class="container">
			<div class="banner-info animated wow zoomIn" data-wow-delay=".5s">
				<h3>ADD NEW PRODUCT</h3>
			<form method="post" action="AddprodAction.php" enctype="multipart/form-data">
        <table style="color:orange;" align="center">
            <caption><h1 style="color:white;"></h1></caption>
            <tr><td>Product ID</td><td><input type="Number" autocomplete="off" required name="pid"></td></tr>
            <tr><td>Product</td><td><input type="text" autocomplete="off" required name="product"></td></tr>
            <tr><td>Image</td><td><input type="file" autocomplete="off" required name="img"></td></tr>
            <tr><td>img1</td><td><input type="file" autocomplete="off" required name="img1"></td></tr>
            <tr><td>img2</td><td><input type="file"  required name="img2"></td></tr>
            <tr><td>img3</td><td><input type="file" required name="img3"></td></tr>
            <tr><td>Specification</td><td><textarea autocomplete="off" required name="spec"></textarea></td></tr>
           
            <tr><td>Price</td><td><input type="Number" autocomplete="off" required name="price"></td></tr>
            <tr><td>Quantity</td><td><input type="Number" autocomplete="off" required name="qty"></td></tr>
            
            <tr><td>Delivery rate&date</td><td><textarea autocomplete="off" required name="del"></textarea></td></tr>
            
            <tr><td><input type="submit" name="submit" value="submit"></td></tr>
            
        </table>
    </form>
				
				<div class="wmuSlider example1">
					<div class="wmuSliderWrapper">
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								<div class="banner-info1">
									
								</div>
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								<div class="banner-info1">
									
								</div>
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								<div class="banner-info1">
									
								</div>
							</div>
						</article>
					</div>
				</div>
					<script src="js/jquery.wmuSlider.js"></script> 
					<script>
						$('.example1').wmuSlider();         
					</script> 
			</div>
		</div>
	</div>


<div>



</div>


	





<?php include 'footer.php'; ?>
	<?php
}
else
{
	header('location:../login.php');
}

?>
<!-- //footer -->



