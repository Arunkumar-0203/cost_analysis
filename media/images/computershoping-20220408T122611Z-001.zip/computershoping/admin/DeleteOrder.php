<?php
include '../connection.php';
$id=$_GET["id"];
$str="delete from order1 where oid='$id'";
mysqli_query($con, $str);

echo "<script>alert('deleted successfull');window.location='vieworder.php'</script>";

?>
