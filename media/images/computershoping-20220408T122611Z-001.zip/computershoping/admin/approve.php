<?php
include '../connection.php';
$id=$_GET["id"];
$str="update login set status='approved' where logid ='$id'";
mysqli_query($con, $str);
echo "<script>alert('approved');window.location='newusers.php'</script>";
?>

