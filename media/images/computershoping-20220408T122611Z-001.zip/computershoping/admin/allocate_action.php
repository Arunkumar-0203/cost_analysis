<?php
$order=$_POST["order"];
$dist = $_POST["dist"];






include '../connection.php';

$sql2="UPDATE order1 SET status='Order Confirm' WHERE oid='$order' ";
mysqli_query($con,$sql2);

$query = "insert into allocate(order_id,dist_id,stat)values('$order','$dist','Allocate')";
mysqli_query($con, $query) or die(mysqli_error($con));


echo"<script>alert('Allocate Sucessfull');window.location='adminhome.php';</script>";
?>




