<?php
include '../connection.php';

echo "<script>window.location='../login.php'</script>";
?>