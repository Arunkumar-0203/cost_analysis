<?php
include '../connection.php';
$id=$_GET["id"];
$str="delete from product where pid='$id'";
mysqli_query($con, $str);
echo "<script>alert('deleted successfull');window.location='ViewProduct.php'</script>";
?>



