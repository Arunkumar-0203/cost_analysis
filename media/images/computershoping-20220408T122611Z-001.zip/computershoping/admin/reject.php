<?php
include '../connection.php';
$id=$_GET["id"];
$str="update login set status='new' where logid='$id'";
mysqli_query($con, $str);
echo "<script>alert('rejected');window.location='newusers.php'</script>";
?>



