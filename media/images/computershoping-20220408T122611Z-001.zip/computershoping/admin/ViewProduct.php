
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<?php
session_start();
if($_SESSION)
{


?>
<html>
<head>
<title>Computer assembly</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Best Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- timer -->
<link rel="stylesheet" href="css/jquery.countdown.css" />
<!-- //timer -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
	
<body>
<!-- header -->
	<?php
	include 'adminheader.php';
	?>
<!-- //header -->
<!-- banner -->
	<div class="banner">
		<div class="container">
			<div class="banner-info animated wow zoomIn" data-wow-delay=".5s">
				<h3>PRODUCT DETAILS</h3>
				<form enctype="multipart/form-data">
        <table align="center"  style="color:orange;">
            <caption><h1 style="color:white;"></h1></caption>
            <tr><th>PRODUCT ID</th><th>PRODUCT NAME</th>
                <th>IMAGE</th><th>SPECIFICATION</th><th>PRICE</th><th>QTY</th></tr>
            <?php
            include '../connection.php';
            $str="select * from product";
            $result=mysqli_query($con,$str);
            while($data=  mysqli_fetch_array($result))
            {
                ?>
            <tr><td><?php echo $data['prodid'];?></td>
                <td><?php echo $data['product'];?></td>
                
               
                <td><img src="upload/<?php echo $data['image'];?>" width="75" height="75"></td>
                <td><?php echo $data['specification'];?></td>
                <td><?php echo $data['price'];?></td>
                <td><?php echo $data['qty'];?></td>
                <td><?php echo $data['delivery'];?></td>
                <td><a style="color:white;" href="UpdateProd.php?id=<?php echo $data['pid'];?>">update</a></td>
                <td><a  style="color:white;" href="DeleteProd.php?id=<?php echo $data['pid'];?>">delete</a></td></tr>
            <?php
            }
            
            ?>
            
        </table>
        </form>
				
				<div class="wmuSlider example1">
					<div class="wmuSliderWrapper">
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								<div class="banner-info1">
									
								</div>
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								<div class="banner-info1">
									
								</div>
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								<div class="banner-info1">
									
								</div>
							</div>
						</article>
					</div>
				</div>
					<script src="js/jquery.wmuSlider.js"></script> 
					<script>
						$('.example1').wmuSlider();         
					</script> 
			</div>
		</div>
	</div>


<div>

 
    <body>
        
    </body>




</div>


	





<?php include 'footer.php'; ?>
	<?php
}
else
{
	header('location:../login.php');
}

?>
<!-- //footer -->




  




     
    



