<?php
include '../connection.php';
if(isset($_POST['submit']))
{


$pid=$_POST["pid"];
$qty=$_POST["qty"];
$pro=$_POST["product"];
$pri=$_POST["price"];
$pic=$_FILES["img"]["name"];
$pic=$_FILES["img"]["tmp_name"];
$file_name=round(microtime(true)*1000).'.jpg';
	move_uploaded_file($pic, 'upload/'.$file_name);
$pic1=$_FILES["img1"]["tmp_name"];
$file_name1=round(microtime(true)*1000).'.jpg';
	move_uploaded_file($pic1, 'upload/'.$file_name1);
$pic2=$_FILES["img2"]["tmp_name"];
$file_name2=round(microtime(true)*1000).'.jpg';
	move_uploaded_file($pic2, 'upload/'.$file_name2);
$pic3=$_FILES["img3"]["tmp_name"];
$file_name3=round(microtime(true)*1000).'.jpg';
	move_uploaded_file($pic3, 'upload/'.$file_name3);

$spec=$_POST["spec"];
$del=$_POST["del"];

$str="insert into product(prodid,product,image,image1,image2,image3,price,qty,specification,delivery)values('$pid','$pro','$file_name','$file_name1','$file_name2','$file_name3','$pri','$qty','$spec','$del')";
mysqli_query($con, $str)or die(mysqli_error($con));
echo "<script>alert('added successfull');window.location='AddProduct.php'</script>";
}
?>

