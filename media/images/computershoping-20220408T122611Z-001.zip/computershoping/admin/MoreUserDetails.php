<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<?php
session_start();
if($_SESSION)
{


?>
<html>
<head>
<title>computer assembly</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Best Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- timer -->
<link rel="stylesheet" href="css/jquery.countdown.css" />
<!-- //timer -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
	
<body>
<!-- header -->
	<div class="header">
		<div class="container">
			<div class="header-grid">
				<!--<div class="header-grid-left animated wow slideInLeft" data-wow-delay=".5s">
					<ul>
						<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">@example.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+1234 567 892</li>
						<li><i class="glyphicon glyphicon-log-in" aria-hidden="true"></i><a href="login.php">Login</a></li>
						<li><i class="glyphicon glyphicon-book" aria-hidden="true"></i><a href="registration.php">Register</a></li>
					</ul>
				</div>-->
				<div class="header-grid-right animated wow slideInRight" data-wow-delay=".5s">
					<ul class="social-icons">
					<li><a href="https://www.facebook.com/" class="facebook"></a></li>
						<li><a href="https://twitter.com/login" class="twitter"></a></li>
						<li><a href="https://www.google.com/" class="g"></a></li>
						<li><a href="https://www.instagram.com" class="instagram"></a></li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="logo-nav">
				<div class="logo-nav-left animated wow zoomIn" data-wow-delay=".5s">
					<h1><a href="adminhome.php">My Store <span>Shop anywhere</span></a></h1>
				</div>
				<div class="logo-nav-left1">
					<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header nav_2">
						<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div> 
					<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
						<ul class="nav navbar-nav">
							 <li class="active"><a href="adminhome.php" class="act">Home</a></li>	
                                                    <li class="active"><a href="viewusers.php" class="act">View Users</a></li>	
                                                    <li class="active"><a href="newusers.php" class="act">New Users</a></li>	
                                                    <li class="active"><a href="AddProduct.php" class="act">Add Product</a></li>	
                                                    <li class="active"><a href="ViewProduct.php" class="act">View Product</a></li>	
                                                    <li class="active"><a href="add_mboard.php" class="act">Add Motherboard</a></li>	
                                                    <li class="active"><a href="view_mboard.php" class="act">Motherboard Details</a></li>	
                                                    <li class="active"><a href="vieworder.php" class="act">View Order</a></li>	
                                                    <li class="active"><a href="../login.php" class="act">Logout</a></li>	
							
							
<!--							<li><a href="">Short Codes</a></li>
							<li><a href="mail.html">Mail Us</a></li>-->
						</ul>
					</div>
					</nav>
				</div>
				
		</div>
	</div>
<!-- //header -->
<!-- banner -->
	<div class="banner">
		<div class="container">
			<div class="banner-info animated wow zoomIn" data-wow-delay=".5s">
				<h3>USER DETAILS</h3>
				<form enctype="multipart/form-data">
        <table align="center" border="5" style="color:red;">
            <caption><h1></h1></caption>
            <th>Full name</th><th>Address</th>
                <th>Age</th><th>Dob</th><th>gender</th>
                <th>Mob</th><th>Email</th></tr>
   <?php 
            
            include '../connection.php';
            $id=$_GET["id"];
            $query = "select * from registration where lid='$id'";
            $result = mysqli_query($con, $query);
            
            while ($data = mysqli_fetch_assoc($result)) {
                ?>
                <tr>
                    <td><?php echo $data['name']?></td>
                   
                    <td><?php echo $data['address']?></td>
                    <td><?php echo $data['age']?></td>
                    <td><?php echo $data['dob']?></td>
                    <td><?php echo $data['gender']?></td>
                    <td><?php echo $data['mob']?></td>
                    <td><?php echo $data['email']?></td>
                   
                    
                    
                   
                    
                </tr>
                <?php
            }
      ?>
        </table>
        </form>
				
				<div class="wmuSlider example1">
					<div class="wmuSliderWrapper">
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								
							</div>
						</article>
					</div>
				</div>
					<script src="js/jquery.wmuSlider.js"></script> 
					<script>
						$('.example1').wmuSlider();         
					</script> 
			</div>
		</div>
	</div>


<div>

  <body>
        
    </body>

</div>


	





<?php include 'footer.php'; ?>
	<?php
}
else
{
	header('location:../login.php');
}

?>
<!-- //footer -->




  

