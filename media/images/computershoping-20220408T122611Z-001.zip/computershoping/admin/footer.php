<div class="footer">
		<div class="container">
			<div class="footer-grids">
				<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".5s">
					<h3>About Us</h3>
					<p>15 billion users.<span>we offered a site for a shoping feel.<span>
					make your own computer.</span>
				.</span></p>
				</div>
				<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".6s">
					<h3>Contact Info</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i><span>muvattupuzha</span></li>
						<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">info.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+918304076541</li>
					</ul>
				</div>
				<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".7s">
					<h3>Flickr Posts</h3>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/vector-computer-mobile-phones-colorful-applic-creative-cloud-application-icon-business-software-social-media-32452698.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/800px_COLOURBOX11074382.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/Creative_Labs_51MF0305AA002_I_Trigue_L3800_Computer_Speaker_429669.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/computermouse12.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/brand-business-cellphone-204611.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/14259a264d0a621577c22951ecd671c5.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/11.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/2.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/d255d4b1f364e00834a57d6e661d96c8.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/micorosoft_surface_dribbble.gif" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/wp2105387.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="ViewProduct.php"><img src="images/apple-computer-keyboard-wallpaper-2.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".8s">
					<h3>Blog Posts</h3>
					<div class="footer-grid-sub-grids">
						<div class="footer-grid-sub-grid-left">
							<a href="ViewProduct.php"><img src="images/14259a264d0a621577c22951ecd671c5.jpg" alt=" " class="img-responsive" /></a>
						</div>
						<div class="footer-grid-sub-grid-right">
							<h4><a href="ViewProduct.php">lighting board and mouse</a></h4>
							<p>Posted On 20/3/2019</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="footer-grid-sub-grids">
						<div class="footer-grid-sub-grid-left">
							<a href="ViewProduct.php"><img src="images/Untitled (2).jpg" alt=" " class="img-responsive" /></a>
						</div>
						<div class="footer-grid-sub-grid-right">
							<h4><a href="ViewProduct.php">lap offer zone</a></h4>
							<p>Posted On 25/3/2019</p>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="footer-logo animated wow slideInUp" data-wow-delay=".5s">
				<h2><a href="adminhome.php">Best Store <span>shop anywhere</span></a></h2>
			</div>
			<div class="copy-right animated wow slideInUp" data-wow-delay=".5s">
				<p>&copy 2016 Best Store. All rights reserved | Design by <a href="">Cyber</a></p>
			</div>
		</div>
	</div>
<!-- //footer -->
</body>
</html>