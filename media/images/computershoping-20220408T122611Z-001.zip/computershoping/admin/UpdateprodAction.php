<?php
include '../connection.php';
$id=$_POST["id"];
$pid=$_POST["prodid"];
$prod=$_POST["product"];
$qty=$_POST["qty"];
$img=$_FILES["file"]["name"];
$img1=$_FILES["file1"]["name"];
$img2=$_FILES["file2"]["name"];
$img3=$_FILES["file3"]["name"];
$spec=$_POST["spec"];
$pri=$_POST["price"];
$del=$_POST["del"];
$str="update product set prodid='$pid',product='$prod',image='$img',image1='$img1',image2='$img2',image3='$img3',specification='$spec',price='$pri',delivery='$del',qty='$qty' where pid='$id'";
mysqli_query($con, $str)or die(mysqli_error($con));
echo "<script>alert('updated successfull');window.location='ViewProduct.php'</script>";



?>

