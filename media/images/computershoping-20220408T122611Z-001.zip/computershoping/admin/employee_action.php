<?php
$name=$_POST["name"];
$address = $_POST["address"];
$age = $_POST["age"];

$gender = $_POST["gender"];
$mob = $_POST["mob"];
$email = $_POST["email"];
$username = $_POST["username"];
$password = $_POST["password"];




include '../connection.php';
$query = "insert into login(username,password,type,status)values('$username','$password','distributers','approved')";
mysqli_query($con, $query) or die(mysqli_error($con));
$logid=mysqli_insert_id($con);
 $sql = "insert into registration(name,address,age,gender,mob,email,lid,username,password)values('$name','$address','$age','$gender','$mob','$email','$logid','$username','$password')";
mysqli_query($con, $sql) or die(mysqli_error($con));

echo"<script>alert('Added Sucessfull');window.location='adminhome.php';</script>";
?>




