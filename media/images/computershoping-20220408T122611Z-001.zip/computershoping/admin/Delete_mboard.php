<?php
include '../connection.php';
$id=$_GET["id"];
$str="delete from motherboard where mid='$id'";
mysqli_query($con, $str)or die(mysqli_error($con));
echo "<script>alert('deleted successfull');window.location='view_mboard.php'</script>";
?>



