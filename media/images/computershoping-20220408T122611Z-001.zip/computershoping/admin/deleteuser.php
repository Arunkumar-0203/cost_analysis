<?php
include '../connection.php';
$id=$_GET['id'];
$str="delete from registration where userid='$id'";
mysqli_query($con, $str);
echo "<script>alert('deleted successfull');window.location='newusers.php'</script>";
?>



