<?php
include './connection.php';
session_start();


$name=$_POST["user"];
$pass=$_POST["pass"];
$str="select * from login where username='$name' and password='$pass'";
$result=  mysqli_query($con, $str);
$data=  mysqli_fetch_array($result);
$_SESSION["log"]=$data['logid'];
$_SESSION["username"]=$data['username'];
 if($data['username']==$name && $data['password']==$pass)

{
   if($data['type']=="admin")
    {
        header("location:admin/adminhome.php");
    }
    else if($data['type']=="user" && $data['status']=="approved")
    {
        header("location:user/ViewProduct.php");
    }
    else if($data['type']=="distributers" && $data['status']=="approved")
    {
        header("location:distributers/home.php");
    }
 else {
        echo "<script>alert('not approved');window.location='login.php'</script>";  
    }
}
else
{
    echo "<script>alert('invalid username or password');window.location='login.php'</script>";
}

?>


