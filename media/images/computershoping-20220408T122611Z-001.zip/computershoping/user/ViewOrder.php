<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<?php
session_start();
if($_SESSION)
{


?>
<html>
<head>
<title>Computer assembly</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Best Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- timer -->
<link rel="stylesheet" href="css/jquery.countdown.css" />
<!-- //timer -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
	
<body>
<!-- header -->
	<?php
	include 'userheader.php';
	?>
<!-- //header -->
<!-- banner -->
	<div class="banner">
		<div class="container">
			<div class="banner-info animated wow zoomIn" data-wow-delay=".5s">
				<h3>MY CART</h3>
				<form enctype="multipart/form-data" action="purchase.php" method="post">
        
        </form>
				<div class="wmuSlider example1">
					<div class="wmuSliderWrapper">
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								<div class="banner-info1">
									
								</div>
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								<div class="banner-info1">
									
								</div>
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								
							</div>
						</article>
					</div>
				</div>
					<script src="js/jquery.wmuSlider.js"></script> 
					<script>
						$('.example1').wmuSlider();         
					</script> 
			</div>
		</div>
	</div>


<div>
    </body>
</html>
    <body>
    	<?php
            include '../connection.php';

            $id=$_SESSION["log"];
          
           // $total=$_POST['total'];
            $str="select * from order1 where lid='$id' and status='new'";
            $result=  mysqli_query($con, $str);
           
           $count=mysqli_num_rows($result);
if($count<=0)
{
       ?> 
       <br><br><br><br><h1 align="center" style="color: red;">Cart Is Empty</h1><br><br><br><br>
       <?php 
   }
   else{



       ?>
     
        <table align="center" border="0">
            <caption><h1>MY CART</h1></caption>
            <tr><th>PRODUCT NAME</th><th>IMAGE</th><th>PRICE</th><th></th></tr>

            <?php
            include '../connection.php';
            
            $id=$_SESSION["log"];
            $str="select * from order1 where lid='$id' and status='new'";
            $res=mysqli_query($con, $str);
            $total=0;
          while($data=  mysqli_fetch_array($res))
          {
          	
          	
              ?>
            <tr>



                <td><?php echo $data['product'];?></td>
                <td><img src="../admin/upload/<?php echo $data['pimage'];?>" width="75" height="75"></td>
                <td><?php echo "Rs.".$data['price'];?></td>

                <td><a href="delete.php?id=<?php echo $data['pid'];?>">Delete</a></td>
               <!--<td><?php echo "Rs.".$data['price'];?></td>-->
            </tr>
            </tr>
            <?php
            $total=$total+$data['price'];
          }
          
            ?>

            <tr><td colspan="2">Total Cost</td><td><input readonly="" type="text" name="total" value="<?php echo $total;?>"/></td></tr>
            <tr><td colspan="3"><center><br><br><a class="btn btn-success" href="purchase.php?tot=<?php echo $total;?>">Proceed To Checkout</a></center></td></tr> <br>
                  
        </table>

        <?php } ?>
        

    </body>
</div>


	





<?php include 'footer.php'; ?>
	<?php
}
else
{
	header('location:../login.php');
}

?>
<!-- //footer -->


