<?php
include '../connection.php';
$id=$_POST["id"];
$name=$_POST["name"];
$add=$_POST["address"];
$age=$_POST["age"];

$gen=$_POST["gender"];
$mob=$_POST["mob"];
$email=$_POST["email"];

$user=$_POST["user"];
$pass=$_POST["pass"];
 $str="update registration set name='$name',address='$add',age='$age',gender='$gen',mob='$mob',email='$email',username='$user',password='$pass' where lid='$id'";
mysqli_query($con, $str);
$str1="update login set username='$user',password='$pass' where logid='$id'";
mysqli_query($con, $str1);
echo "<script>alert('updated successfull');window.location='editprof.php'</script>";
?>


