 <!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<?php
session_start();
if($_SESSION)
{


?>
<html>
<head>
<title>Computer assembly</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Best Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- timer -->
<link rel="stylesheet" href="css/jquery.countdown.css" />
<!-- //timer -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
	
<body>
<!-- header -->
	<?php
	include 'userheader.php';
	?>
<!-- //header -->
<!-- banner -->
	<div class="banner">
		<div class="container">
			<div class="banner-info animated wow zoomIn" data-wow-delay=".5s">
				<h3>SEARCH RESULT</h3>
				
				<div class="wmuSlider example1">
					<div class="wmuSliderWrapper">
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								
							</div>
						</article>
					</div>
				</div>
					<script src="js/jquery.wmuSlider.js"></script> 
					<script>
						$('.example1').wmuSlider();         
					</script> 
			</div>
		</div>
	</div>


<div>
  					








					<?php
						include '../connection.php';
						if(isset($_POST['submit']))
						{

						 $search=$_POST['name'];
                   						

 
$getName="SELECT * FROM product where product='$search'";
$kp=mysqli_query($con,$getName);
while($row=mysqli_fetch_assoc($kp))
{




echo     ' <table cellpadding="10">
       <tr><td><section>
<div class="single-service-page">

								
														</div><br></section></td>
<form>

									
									   
										
								<td>	<h1 class="mb-10">Search Result</h1>
								<a href="ViewProduct.php">
								<img width=100px src="../admin/upload/'.$row["image"].'"></a>
									<div class="mt-10">
									<label>Product id</label>
										<input type="text" readonly value='. $row["prodid"] .' class="form-control">
									</div>
									<div class="mt-10">
									<label>Name</label>
										<input type="text"  readonly value="'. $row["product"] .'"  class="form-control">
									</div><br>
										
									<div class="mt-10">
									<label>Specification</label>
										<input type="text" readonly value="'.$row["specification"].'" class="form-control">
									</div>
									<div class="mt-10">
									<label>Price</label>
										<textarea readonly placeholder="'.$row["price"] .'" class="form-control"></textarea>
										
									
									';


}
}


?>
</div>



<?php include 'footer.php'; ?><?php
}
else
{
	header('location:../login.php');
}

?>

<!-- //footer -->



   




    









