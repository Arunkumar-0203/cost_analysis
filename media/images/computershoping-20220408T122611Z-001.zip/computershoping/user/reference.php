	<?php
	session_start();
	if($_SESSION)
	{
?>

	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="codepixer">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Elephant management</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">	
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>
			 <?php
			 include 'userheader.php';
			 ?>

			 			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row fullscreen d-flex align-items-center justify-content-start">
						<div class="banner-content col-lg-12">
							
							<span class="bar"></span>
							<h1 class="text-white">
							Elephant details <br>
								
							</h1>
							
						</div>
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

		<!-- Start service-page Area -->
			<section class="service-page-area section-gap">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<?php
						include '../connect.php';
						$search=$_POST['search'];

$getName="SELECT * FROM elephant,musth,schedule WHERE elephant.elephant_id=musth.elephant_id=schedule.elephant_id AND elephant_name='$search'";
$kp=mysqli_query($con,$getName);

if ($row=mysqli_fetch_assoc($kp)) {
	# code...



                                
		$elephant_id = $row['elephant_id'];

          $elephant_name=$row['elephant_name'];
                                $owner_name= $row['owner_name'];
   	
   	$district=$row['district'];

   	$region=$row['region'];
   	$address=$row['address'];
   	$phone_no=$row['phone_no'];
    $email=$row['email'];
    $image=$row['image'];
    $schedule_start=$row['schedule_start'];
    $schedule_end=$row['schedule_end'];
    $event=$row['event'];
    $place=$row['place'];
  	$musth_start=$row['start_date'];
  	$musth_end=$row['end_date'];





echo ' <table cellpadding="10"  >
       <tr><td><section>
<div class="single-service-page">
<img width=300px src="../admin/img/'.$image.'">
								
														</div><br></section></td>
<form>

									
									   
										
								<td>	<h1 class="mb-10">Elephant profile</h1>
									<div class="mt-10">
									<label>Name</label>
										<input type="text" readonly value="'. $elephant_name .'" class="form-control">
									</div>
									<div class="mt-10">
									<label>Owner</label>
										<input type="text"  readonly value="'. $owner_name .'"  class="form-control">
									</div><br>
										<div class=" mt-10">
										<label>District</label>
										<input type="text"  readonly value="'. $district .'" class="form-control">
									</div>
									<div class="mt-10">
									<label>Region</label>
										<input type="text" readonly value="'.$region.'" class="form-control">
									</div>
									<div class="mt-10">
									<label>Address</label>
										<textarea readonly placeholder="'.$address .'" class="form-control"></textarea>
										
									</div>
									<div class="mt-10">
									<label>Phone</label>
										<input type="text" readonly value="'. $phone_no .'" class="form-control">
									</div>
									<div class="mt-10">
									<label>Email</label>
										<input type="text"  readonly value="'. $email .'" class="form-control">
									</div>
									
								</form></td></tr>

									<div class="mt-10">
								<div class="container">
								
								<div class="row justify-content-between align-items-center">
                     
          

           
           <tr><td colspan=4 align=center>

           <h1 class="mb-10">Schedule</h1></td>
           </tr>
           <th>Event</th>
           <th>Place</th>
           <th>From</th>
           <th>To</th>';
          

$sql="SELECT * FROM schedule,elephant WHERE schedule.elephant_id=elephant.elephant_id and elephant_name = '$elephant_name'";
$kp1=mysqli_query($con,$sql);

while($row=mysqli_fetch_assoc($kp1)) {


      echo '<tr><td>'.$row["event"].' </td>
           <td>'.$row["place"].' </td>
           <td>'.$row["schedule_start"].' </td>
           <td>'.$row["schedule_end"].' </td>
           </tr>';
       }
       
                
       echo ' </div>
           </div></div>
                            <td><form>
           <h1 class="mb-10">Musth period</h1>
           <div class="mt-10">
           <label>From</label>
           <input type=text readonly value="'.$musth_start.'" class="form-control"></div>
           <div class="mt-10">
           <label>To</label>
           <input type=text readonly value="'.$musth_end.'" class="form-control"></div>
									</td>
								</tr></table>';
}

	else{
	 echo '<script>alert(" elephant not found..");window.location.href="search.php";</script>';

}
					
            include 'userfooter.php';
		


					?>	
					</div>
				</div>	
			</section>
			<!-- End service-page Area -->
			

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>			
			<script src="js/jquery.sticky.js"></script>
			<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>				
			<script src="js/jquery.nice-select.min.js"></script>			
			<script src="js/parallax.min.js"></script>	
			<script src="js/waypoints.min.js"></script>
			<script src="js/jquery.counterup.min.js"></script>			
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>


<?php
}
else
{
header('location:../login.php');
}
?>
