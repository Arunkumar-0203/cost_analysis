</html>
</body>
<title></title>
		<div>
			<li><form action="search1.php" method="post">
                     	 <tr>
                       <td></td>
                       <td><input type="text" name="name" placeholder="search for product" required></td>

                       <td><button  class="btn btn-primary btn-lg" type="Submit" name="submit" value="Search"> Search</button></td>
                      
                       
                       </tr>
                      </li>

                      </form>	
                  </div>

                <div class="footer">
    <div class="container">
      <div class="footer-grids">
        <!--<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".5s">
          <h3>About Us</h3>
          <p>15 billion users.<span>we offered a site for a shoping feel.<span>
          make your own computer.</span>
        .</span></p>
        </div>
        <div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".6s">
          <h3>Contact Info</h3>
          <ul>
            <li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>,kadavoor, <span>muvattupuzha po paigottor.</span></li>
            <li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">ankitpchandran353.com</a></li>
            <li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+918304076541</li>
          </ul>
        </div>-->
        <div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".7s">
          <h3>Flickr Posts</h3>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/assembled-wifi-punta-original-imaff39gzzzxbekg.jpeg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/wires/c-e-15-feet-vga-male-to-female-extension-cable-with-ferrites-original-imaeuuuufgzpgq3u.jpeg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/chase2-foxin-original-imaez85sxzwfksw3.jpeg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/background/Screenshot_2015-04-06-15-18-20.png" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/background/27950332562_f4371e36f6_b.jpg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/wires/lootmela-7-original-imae9zxnhhjzraxg.jpeg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/11.jpg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/2.jpg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/lap charger/lapower-65w-charger-for-thinkpad-original-imaf6jjjxwrcvpvs.jpeg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/keyboard/1/cosmic-byte-cb-gk-08-corona-original-imaffvgtfgqgfzhy.jpeg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/mouse/1/hp-x3000-original-imaexgnhtz3eaftx.jpeg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="footer-grid-left">
            <a href="ViewProduct.php"><img src="images/monitor/1/hp-t3m70aa-22es-original-imaehbhgzbyjqkuh.jpeg" alt=" " class="img-responsive" /></a>
          </div>
          <div class="clearfix"> </div>
        </div>
        <div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".8s">
          <h3>Blog Posts</h3>
          <div class="footer-grid-sub-grids">
            <div class="footer-grid-sub-grid-left">
              <a href="ViewProduct.php"><img src="images/os/1/microsoft-fqc-06949-original-imaehhtdcenudhqz.jpeg" alt=" " class="img-responsive" /></a>
            </div>
            <div class="footer-grid-sub-grid-right">
              <h4><a href="ViewProduct.php">lighting board and mouse</a></h4>
              <p>Posted On 20/3/2019</p>
            </div>
            <div class="clearfix"> </div>
          </div>
          <div class="footer-grid-sub-grids">
            <div class="footer-grid-sub-grid-left">
              <a href="ViewProduct.php"><img src="images/Untitled (2).jpg" alt=" " class="img-responsive" /></a>
            </div>
            <div class="footer-grid-sub-grid-right">
              <h4><a href="ViewProduct.php">lap offer zone</a></h4>
              <p>Posted On 25/3/2019</p>
            </div>
            <div class="clearfix"> </div>
          </div>
        </div>
        <div class="clearfix"> </div>
      </div>
     
    </div>
  </div>
<!-- //footer -->
</body>
</html>