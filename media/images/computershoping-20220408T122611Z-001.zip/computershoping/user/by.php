<?php
          
            include '../connection.php';
           session_start();
            
           $id=$_GET["id"];

$sql="SELECT * FROM order1 WHERE lid='$id' AND status='new'";

$rs=mysqli_query($con,$sql);
while($row=mysqli_fetch_assoc($rs)) 

{

$pid=$row['pid'];

$sql2="UPDATE product SET qty=(qty-'1') WHERE pid='$pid' ";
mysqli_query($con,$sql2);

            $sql="UPDATE order1  SET status='Order Placed',deliv='Null' WHERE  lid='$id'";
           mysqli_query($con, $sql);
           echo "<script>alert('Order successfully');window.location.href='ViewProduct.php';</script>";
       }
            ?>