
<!DOCTYPE html>
<?php
session_start();
if($_SESSION)
{


?>




<html>
<head>
<title>Computer assembly</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Best Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
    function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- timer -->
<link rel="stylesheet" href="css/jquery.countdown.css" />
<!-- //timer -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();

$('input[type="checkbox"]').on('click',function(){
var selected = $(this).parent().parent().parent();    $(selected).toggleClass('highlight');
});

</script>
<!-- //animation-effect -->

<style type="text/css">
  

*{
  margin:0;
  padding:0;
}
body{
  height:100vh;
  overflow:hidden;
  background:linear-gradient(-40deg,white,lightgrey);
  box-sizing:border-box;
  font-family: "Montserrat", sans-serif;
}
#wrapper{
  height:480px;
  width:700px;
  background:#fff;
  border:1px solid grey;
  border-radius:10px;
  margin:3em auto 0 auto;
  overflow:hidden;
  box-shadow:0px 2px 25px #000;
}
.row{
  display:flex;
  justify-content:center;
}
.row:nth-of-type(1) .col-xs-5{
  display:flex;
  flex-direction:column;
  align-items:center;
  background:#e6e6e6;
/*   border:solid 1px transparent; */
  border-radius:4px;
  margin:1em 5px;
}
.row:nth-of-type(1) .col-xs-5 #cards{
  display:flex;
  flex-direction:row;
  flex-wrap:nowrap;
  justify-content:center;
}
.row:nth-of-type(1) .col-xs-5 #cards img{
  width:100px;
  height:100px;
}

.row:nth-of-type(2) .col-xs-5{
  display:flex;
  flex-direction:column;
  justify-content:space-around;
  flex-basis:45%;
}
.row:nth-of-type(2) .col-xs-5 input{
  border:2px solid lightgrey;
  height:35px;
  border-radius:10px;
  padding-left:10px;
}
.row .col-xs-5 input:focus, .row:nth-of-type(3) .col-xs-2 input:focus{
  border-color:green;
  outline:0;
}
label{
  position:relative;
}
 .fa{
  position:absolute;
  right:25px;
  bottom:10px;
}
.row-three{
  display:flex;
  justify-content:space-around;
  align-items:baseline;
  align-content:space-between;
  margin:2em 1em 2.4em 1em;
}
.row:nth-of-type(3) .col-xs-2{
  flex-basis:50%;
}
.row:nth-of-type(3) .col-xs-5{
  flex-basis:40%;
  align-items:baseline;
}
.row:nth-of-type(3) .col-xs-2 input{
  height:35px;
  border:2px solid lightgrey;
  border-radius:10px;
  padding-left:10px;
}
.row:nth-of-type(3) .col-xs-5 .small{
  font-size:.70em;
}
footer{
  height:80px;;
  background:#e6e6e6;
  display:flex;
  flex-direction:row;
  justify-content:space-between;
  align-items:center;
}
footer .btn{
  margin:50px 15px 55px 15px;
  border-radius:20px;
  padding:.65em 1.6em;
}
footer :nth-child(1){
  background-color:#fff;
  color:#f62f5e;
}
footer :nth-child(2){
  background-color:#f62f5e;
  color:#fff;
}
.col-xs-5.highlight{
  border:solid 1px blue;
}
</style>
</head>
  
<body>
<!-- header -->
  <?php 

$tu=$_GET['tot'];
$id=$_SESSION['log'];

  ?>
<!-- //header -->
<!-- banner -->
  <div class="banner">
    <div class="container">
      <div class="banner-info animated wow zoomIn" data-wow-delay=".5s">


<h1 style="color: white">Payment</h1>
 <form action="payment_confirm.php">
<div id="wrapper">
  <div class="row">
    <div class="col-xs-5">
      <div id="cards">
        
      </div><!--#cards end-->
      <div class="form-check">
  <label class="form-check-label" for='card'>
    
    Pay <?php echo $tu; ?>.00 with credit card
  </label>
</div>
    </div><!--col-xs-5 end-->
    <div class="col-xs-5">
      <div id="cards">
        
      </div><!--#cards end-->
      <!-- <div class="form-check">
  <label class="form-check-label" for='paypal'>
    
    Pay $150.00 with PayPal
  </label>
</div> -->
    </div><!--col-xs-5 end-->
  </div><!--row end-->
 
  <div class="row">
    <div class="col-xs-5">
      <i class="fa fa fa-user"></i>
      <label for="cardholder">Cardholder's Name</label>
      <input type="text" name="name" id="cardholder" required="">
    </div><!--col-xs-5-->
    <div class="col-xs-5">
      <i class="fa fa-credit-card-alt"></i>
      <label for="cardnumber">Card Number</label>
      <input type="number" id="cardnumber" name="number" required patern ="[0-9]{14}" >
    </div><!--col-xs-5-->
  </div><!--row end-->
  <div class="row row-three">
    <div class="col-xs-2">
      <i class="fa fa-calendar"></i>
      <label for="date">Valid thru</label>
      <input type="date" placeholder="MM/YY" id="date" required="">
    </div><!--col-xs-3-->
    <div class="col-xs-2">
      <i class="fa fa-lock"></i>
      <label for="date">CVV / CVC *</label>
      <input type="password" required patern ="[0-9]{3}" >
    </div><!--col-xs-3-->
    <div class="col-xs-5">
      <span class="small">* CVV or CVC is the card security code, unique three digits number on the back of your card seperate from its number.</span>
    </div><!--col-xs-6 end-->
  </div><!--row end-->
  <footer>
    <a href="viewOrder.php" class="btn">Back</a>
    <a type="submit" href="by.php?id=<?php echo $id; ?>" class="btn">Pay now</a>
    
  </footer>
</div><!--wrapper end-->


  </form>





        <!--<form enctype="multipart/form-data" action="purchaseaction.php" method="post">
        <table style="color:black; border="5" align="center">
            <?php

            include '../connection.php';
            
            $id=$_SESSION["log"];
             $total=$_POST['total'];
            $str="select * from order1 where lid='$id' and status='new'";
            $result=  mysqli_query($con, $str);
           
            while($data=  mysqli_fetch_array($result))
            {
                ?>
            <tr><td>Product   :</td><td><input type="text" name="product" value="<?php echo $data['product'];?>"></td></tr>
            <tr><td>Image   :</td><td><input type="text" name="file" value="<?php echo $data['pimage'];?>"</td></tr>
           
            
          
 <?php


 
            }
            ?>
             <tr><td>Total   :</td><td><input type="text" name="total" value="<?php echo $total;?>"></td></tr>
              <tr><td><input type="submit" name="submit" value="OK"></td></tr>
              
        </table>
        </form>-->
        <div class="wmuSlider example1">
          <div class="wmuSliderWrapper">
            <article style="position: absolute; width: 100%; opacity: 0;"> 
              <div class="banner-wrap">
                
              </div>
            </article>
            <article style="position: absolute; width: 100%; opacity: 0;"> 
              <div class="banner-wrap">
                
              </div>
            </article>
            <article style="position: absolute; width: 100%; opacity: 0;"> 
              <div class="banner-wrap">
                
              </div>
            </article>
          </div>
        </div>
          <script src="js/jquery.wmuSlider.js"></script> 
          <script>
            $('.example1').wmuSlider();         
          </script> 
      </div>
    </div>
  </div>


<div>
    

  
  <body>

    
        
    </body>



</div>


  








    



	


<?php include 'footer.php'; ?>



<?php
}
else
{
	header('location:../login.php');
}

?>

<!-- //footer -->



   




    

