 <!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
session_start();
if($_SESSION)
{


?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <table>
            <?php
          
            include '../connection.php';
            
            $id=$_SESSION["log"];
            $str="select * from registration where lid='$id'";
            $result=  mysqli_query($con, $str);
            if($data=  mysqli_fetch_array($result))
            {
            $lid=$data['lid'];    
            $fullname=$data['name'];
          
            $add=$data['address'];
            $mob=$data['mob'];
           
            
           }
           
           $id1=$_GET["id"];
           
           $str1="select * from product where pid='$id1'";
         
           $result1=  mysqli_query($con, $str1);
           if($data1=  mysqli_fetch_array($result1))
           {
               $did=$data1['pid'];
               $product=$data1['product'];
               $img=$data1['image'];
               $pri=$data1['price'];
               $del=$data1['delivery'];
           }
         $str3="insert into order1(lid,c_name,product,pimage,price,deliv,mobi,addr,pid,status)values('$lid','$fullname','$product','$img','$pri','$del','$mob','$add','$did','new')";
           mysqli_query($con, $str3)or die(mysqli_error($con));
          echo "<script>alert('Add To Cart Successfully');window.location='ViewProduct.php'</script>";
            ?>
            
        </table>
    </body>
</html>
<?php
}
else
{
  header('location:../login.php');
}

?>
