<?php

include '../connection.php';
$delete=$_GET['id'];
$ss="delete from order1 where pid=$delete";
$ww=mysqli_query($con,$ss);
header("location:vieworder.php");

?>