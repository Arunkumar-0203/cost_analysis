<?php
include '../connection.php';
session_start();
$amt=0;
$pin=$_POST['pin'];
$amt=$_POST['total'];
$id=$_SESSION['log'];
$bal=0;
 $str="select * from bank where lid='$id' and pincode='$pin'";
$res=  mysqli_query($con, $str);
if($data=  mysqli_fetch_assoc($res))
{
     $bal=$data['amount'];
     $amt;
    if($bal>=$amt)
    {
         $bal1=$bal-$amt;
         $qu="update bank set amount='$bal1' where lid='$id'";
        mysqli_query($con, $qu);
    }
 else {
      echo "<script>alert('Insufficiant Balance!..');window.location='ViewOrder.php';</script>";   
    }
    
}
else
{
 echo "<script>alert('Invalid Id!..');window.location='userhome.php';</script>";      
}
$str4="select * from order1";
$res=  mysqli_query($con, $str4);
$data=  mysqli_fetch_array($res);
$oid=$data['oid'];
 $str5="update order1 set status='approved' where lid='$id'";
mysqli_query($con, $str5)or die(mysqli_error($con));
 echo "<script>alert('susccesfull purchased!..');window.location='ViewProduct.php'</script>";
?>
