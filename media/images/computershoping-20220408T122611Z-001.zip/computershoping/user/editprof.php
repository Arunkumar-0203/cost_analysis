<?php
session_start();
if($_SESSION)
{


?>
<!DOCTYPE html>
<html>
<head>
<title>Computer assembly</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Best Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- timer -->
<link rel="stylesheet" href="css/jquery.countdown.css" />
<!-- //timer -->
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
	
<body>
<!-- header -->
	<?php include'userheader.php';
	?>
<!-- //header -->
<!-- banner -->
	<div class="banner">
		<div class="container">
			<div class="banner-info animated wow zoomIn" data-wow-delay=".5s">
				<h3>MY ACCOUNT </h3>
				<!--<form action="editprofaction.php" method="POST" enctype="multipart/form-data">
        <table align="center">
            <caption><h1>Edit Profile</h1></caption>
            <?php
            include '../connection.php';
            
      $id=$_SESSION["log"];
            $str="select * from registration where lid='$id'";
            $result=mysqli_query($con, $str);
            while($data=mysqli_fetch_array($result))
            {
                ?>
                
            <tr><td><input type="hidden" name="id" value="<?php echo $data['lid'];?>"></td></tr>
            <tr><td>Full Name</td><td><input type="text" name="name" value="<?php echo $data['name'];?>"></td></tr>
            
            <tr><td>Address</td><td><textarea name="address"><?php echo $data['address'];?></textarea></td></tr>
            <tr><td>Age</td><td><input type="text" name="age" value="<?php echo $data['age'];?>"></td></tr>
            <tr><td>DOB</td><td><input type="date" name="dob" value="<?php echo $data['dob'];?>"></td></tr>
           <?php
           $gend=$data['gender'];
           if($gend=='male')
           {
               ?>
            <tr><td>Gender</td><td><input type="radio" name="gender" value="male" checked>Male<input type="radio" name="gender" value="female">Female</td></tr>
            <?php
           }
 else {
     ?>
            <tr><td>gender</td><td><input type="radio" name="gender" value="male">Male<input type="radio" name="gender" value="female" checked>Female</td></tr>
 <?php
 
 }
     ?>
            
 
            
           
          <tr><td>Mob</td><td><input type="text" name="mob" value="<?php echo $data['mob'];?>"></td></tr>
          <tr><td>Email</td><td><input type="email" name="email" value="<?php echo $data['email'];?>"></td></tr>
          
            <tr><td>Username</td><td><input type="text" name="user" value="<?php echo $data['username'];?>"></td></tr>
            <tr><td>Password</td><td><input type="text" name="pass" value="<?php echo $data['password'];?>"></td></tr>
            <tr><td><input type="submit" name="submit" value="submit"></td></tr>
           <?php
            }
            ?>
            
        </table>-->
    </form>
				<div class="wmuSlider example1">
					<div class="wmuSliderWrapper">
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								
							</div>
						</article>
					</div>
				</div>
					<script src="js/jquery.wmuSlider.js"></script> 
					<script>
						$('.example1').wmuSlider();         
					</script> 
			</div>
		</div>
	</div>


<div>
	<body>
   <form action="editprofaction.php" method="POST" enctype="multipart/form-data">
        <table align="center">
            <caption><h1>CHANGE MY ACCOUNT</h1></caption>
            <?php
            include '../connection.php';
            
      $id=$_SESSION["log"];
            $str="select * from registration where lid='$id'";
            $result=mysqli_query($con, $str);
            while($data=mysqli_fetch_array($result))
            {
                ?>
                
            <tr><td><input type="hidden" name="id" value="<?php echo $data['lid'];?>"></td></tr>
            <tr><td>FULL NAME</td><td><input type="text" name="name" required pattern="[A-Z a-z]{}" value="<?php echo $data['name'];?>" ></td></tr>
            
            <tr><td>ADDRESS</td><td><textarea name="address" required><?php echo $data['address'];?></textarea></td></tr>
            <tr><td>AGE</td><td><input type="number" name="age" required value="<?php echo $data['age'];?>"></td></tr>
            
           <?php
           $gend=$data['gender'];
           if($gend=='male')
           {
               ?>
            <tr><td>GENDER</td><td><input type="radio" name="gender" value="male" required checked>Male<input type="radio" name="gender" value="female" required>Female</td></tr>
            <?php
           }
 else {
     ?>
            <tr><td>gender</td><td><input type="radio" name="gender" value="male">Male<input type="radio" name="gender" value="female" checked>Female</td></tr>
 <?php
 
 }
     ?>
            
 
            
           
          <tr><td>MOB</td><td><input type="text" name="mob"  value=" <?php echo $data['mob'];?>" requiredpattern="[0-9]{10}"></td></tr>
          <tr><td>EMAIL</td><td><input type="email" name="email" value="<?php echo $data['email'];?>" required></td></tr>
          
            <tr><td>USERNAME</td><td><input type="text" name="user" value="<?php echo $data['username'];?>" required></td></tr>
            <tr><td>PASSWORD</td><td><input type="text" name="pass" value="<?php echo $data['password'];?>" required></td></tr>
            <tr><td><input type="submit" name="submit" value="submit"></td></tr>
           <?php
            }
            ?>
            
        </table>
    </form> 
</body>


</div>


	





<?php include 'footer.php'; ?>
<!-- //footer -->
<?php
}
else
{
	header('location:../login.php');
}

?>


   


