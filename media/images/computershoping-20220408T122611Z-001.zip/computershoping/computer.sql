-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2020 at 09:08 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `computer`
--

-- --------------------------------------------------------

--
-- Table structure for table `allocate`
--

CREATE TABLE `allocate` (
  `a_id` int(50) NOT NULL,
  `stat` varchar(50) NOT NULL,
  `dist_id` int(50) NOT NULL,
  `order_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `allocate`
--

INSERT INTO `allocate` (`a_id`, `stat`, `dist_id`, `order_id`) VALUES
(1, 'Completed', 20, 49),
(3, 'Allocate', 20, 53),
(4, 'Allocate', 23, 50),
(5, 'Allocate', 23, 54);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `logid` int(10) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`logid`, `username`, `password`, `type`, `status`) VALUES
(6, 'david1', 'david1', 'user', 'approved'),
(7, 'jacob', 'jacob', 'user', 'approved'),
(8, 'junaid', 'junaid', 'user', 'new'),
(9, 'admin', 'admin', 'admin', 'approved'),
(10, 'maher', 'maher', 'user', 'approved'),
(11, 'alan', 'alan', 'user', 'approved'),
(12, 'miyad', 'miyad', 'user', 'approved'),
(13, '', '', 'user', 'new'),
(14, '', '', 'user', 'new'),
(15, '', '', 'user', 'new'),
(16, '', '', 'user', 'new'),
(17, 'jas', 'jas', 'user', 'new'),
(18, 'voter', 'voter', 'user', 'approved'),
(19, 'sam', 'sam', 'user', 'approved'),
(20, 'aswin', 'aswin', 'distributers', 'approved'),
(21, 'shyam', 'shyam', 'user', 'approved'),
(22, 'gison', 'gison', 'user', 'approved'),
(23, 'arun', 'arun', 'distributers', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `order1`
--

CREATE TABLE `order1` (
  `oid` int(10) NOT NULL,
  `lid` int(10) DEFAULT NULL,
  `c_name` varchar(50) DEFAULT NULL,
  `addr` varchar(100) DEFAULT NULL,
  `product` varchar(50) DEFAULT NULL,
  `pimage` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `pid` int(10) DEFAULT NULL,
  `mobi` varchar(11) DEFAULT NULL,
  `deliv` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order1`
--

INSERT INTO `order1` (`oid`, `lid`, `c_name`, `addr`, `product`, `pimage`, `price`, `pid`, `mobi`, `deliv`, `status`) VALUES
(49, 19, 'sambhu', 'sreee', 'Key Board', '1600791293101.jpg', '1000', 27, '9249902771', 'delivery 2-2-2020', 'Order Confirm'),
(50, 19, 'sambhu', 'sreee', 'Key Board', '1600791293101.jpg', '1000', 27, '9249902771', 'Null', 'Order Confirm'),
(52, 19, 'sambhu', 'sreee', 'Acer One s100s', 'AcerOne10-2.jpg', '14009', 4, '9249902771', 'Null', 'Order Placed'),
(53, 21, 'Shyam', 'Adimali', 'Apple MacBook', 'Apple-MacBook-Pro.jpg', '53888', 3, '9212121212', 'Null', 'Order Confirm'),
(54, 22, 'Gison', 'Aluva', 'Mouse', '1600843710319.jpg', '2000', 28, '8945342345', 'Null', 'Order Confirm');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(10) NOT NULL,
  `prodid` int(10) DEFAULT NULL,
  `product` varchar(50) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `image1` varchar(50) DEFAULT NULL,
  `image2` varchar(50) DEFAULT NULL,
  `image3` varchar(50) DEFAULT NULL,
  `specification` varchar(1000) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `qty` int(50) NOT NULL,
  `delivery` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `prodid`, `product`, `image`, `image1`, `image2`, `image3`, `specification`, `price`, `qty`, `delivery`) VALUES
(1, 100121, 'HP IS-BE 004tu.', 'HP-15-be004tu-Notebook.jpg', 'sleekbook_4_151238414233.jpg', '4zu3macbook12.jpg', '491217041-2_1.jpg', 'HP 15-5 th generation intel core i3-4GB RAM-500GB HDD-39.62 cm(black).', '26279', 12, 'Standard Delivery(+)Rs.49\r\nStandard Delivery in 2-5 days'),
(3, 11021, 'Apple MacBook', 'Apple-MacBook-Pro.jpg', 'Apple-MacBook-Pro-2016-release-721681.jpg', 'Apple-MacBook-Pro-upgrade-517817.jpg', '4zu3macbook12.jpg', 'Intel core i5-4GB RAM-500GB HDD-33.78 cms (silver)', '53888', 9, 'Standard Delivery(+)Rs.49\r\nStandard Delivery in 2-5 days'),
(4, 32456, 'Acer One s100s', 'AcerOne10-2.jpg', 'AcerOne10.jpg', 'slide6.jpg', '4zu3macbook12.jpg', 'Intel Atom-2GB RAM-#@ GB eMMC-25.65 cm Touchscreen', '14009', 14, 'Standard Delivery(+)Rs.49\r\nStandard Delivery in 2-5 days'),
(27, 1244, 'Key Board', '1600791293101.jpg', '1600791293103.jpg', '1600791293105.jpg', '1600791293116.jpg', 'Lighting Keyboard', '1000', 14, 'Standard Delivery(+)Rs.49\r\nStandard Delivery in 2-3 days'),
(28, 33423, 'Mouse', '1600843710319.jpg', '1600843710321.jpg', '1600843710323.jpg', '1600843710329.jpg', 'Mouse', '2000', 19, '3-4 day delivary with free delivery cost');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `userid` int(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mob` varchar(11) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `lid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`userid`, `name`, `address`, `gender`, `username`, `password`, `email`, `mob`, `age`, `lid`) VALUES
(1, 'david john1', 'asdfg\r\njgd\r\n1213\r\n123\r\n5467', 'male', 'david1', 'david1', 'david@gmail1.com', '9897909895', 25, 6),
(2, 'jacob', 'ds', 'male', 'jacob', 'jacob', 'wq@gmail.com', '2345678901', 33, 7),
(4, 'maher zain', 'jhfjhki\r\nsjkws\r\n97', 'male', 'maher', 'maher', 'maher@nb.com', '1234567832', 32, 10),
(5, 'alan', 'hglkijhlk\r\nkjgkj', 'male', 'alan', 'alan', 'alan@mn.com', '674567677', 32, 11),
(6, 'miyad', ';kljl\r\njhfjh', 'male', 'miyad', 'miyad', 'miyad@mn.com', '76543278', 33, 12),
(7, 'jas', 'hjgjgkjbkl', 'male', 'jas', 'jas', 'jas@mn.com', '875875875', 34, 17),
(8, 'david john', 'tyh', 'male', 'voter', 'voter', 'arunraj0861@gmail.com', '9567599894', 22555, 18),
(9, 'sambhu', 'sreee', 'male', 'sam', 'sam', 'msambhunarayan@gmail.com', '9249902771', 21, 19),
(10, 'Aswin', 'Muvattupuzha', 'male', 'aswin', 'aswin', 'Aswin@gmail.com', '9876564534', 21, 20),
(11, 'Shyam', 'Adimali', 'male', 'shyam', 'shyam', 'Shyam@gmail.com', '9212121212', 25, 21),
(12, 'Gison', 'Aluva', 'male', 'gison', 'gison', 'gison@gmail.com', '8945342345', 21, 22),
(13, 'Arun', 'Alapuzha', 'male', 'arun', 'arun', 'arun@gmail.com', '9078674534', 26, 23);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `allocate`
--
ALTER TABLE `allocate`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `order1`
--
ALTER TABLE `order1`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allocate`
--
ALTER TABLE `allocate`
  MODIFY `a_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `logid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `order1`
--
ALTER TABLE `order1`
  MODIFY `oid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `userid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
