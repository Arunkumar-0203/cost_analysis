<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
   <body>
  
    </body>
</html>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Best Store a Ecommerce Online Shopping Category Flat Bootstrap Responsive Website Template | Register :: w3layouts</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Best Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script src="js/jquery.min.js"></script>
<!-- //js -->
<!-- cart -->
	<script src="js/simpleCart.min.js"> </script>
<!-- cart -->
<link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
<!-- for bootstrap working -->
	<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
	
<body>
<!-- header -->
	<div class="header">
		<div class="container">
			<div class="header-grid">
				<div class="header-grid-left animated wow slideInLeft" data-wow-delay=".5s">
					<ul>
						<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">@info.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+98304 <span>07</span> 6541</li>
						<li><i class="glyphicon glyphicon-log-in" aria-hidden="true"></i><a href="login.php">Login</a></li>
                                                <li class="active"><i class="glyphicon glyphicon-book" aria-hidden="true"></i><a href="registration.php">Register</a></li>
					</ul>
				</div>
				<div class="header-grid-right animated wow slideInRight" data-wow-delay=".5s">
					<ul class="social-icons">
						<li><a href="https://www.facebook.com/" class="facebook"></a></li>
						<li><a href="https://twitter.com/login" class="twitter"></a></li>
						<li><a href="https://www.google.com/" class="g"></a></li>
						<li><a href="https://www.instagram.com" class="instagram"></a></li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="logo-nav">
				<div class="logo-nav-left animated wow zoomIn" data-wow-delay=".5s">
					<h1><a href="home.php">make your computer.com<span>Shop anywhere</span></a></h1>
				</div>
				<div class="logo-nav-left1">
					<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header nav_2">
						<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
					
<!-- //header -->
<!-- breadcrumbs -->
	
<!-- //breadcrumbs -->
<!-- register -->
	<div class="register">
		<div class="container">
			<h3 class="animated wow zoomIn" data-wow-delay=".5s">Register Here</h3>
			<p class="est animated wow zoomIn" data-wow-delay=".5s"></p>
			<div class="login-form-grids">
				<h5 class="animated wow slideInUp" data-wow-delay=".5s"></h5>
				     <form method="post" action="regaction.php" enctype="multipart/form-data">
            <table align="center" cellspacing="40">
                <caption><h1></h1></caption>
                <tr><td><label>Full Name</label></td><td><input autocomplete="off" type="text" name="name" placeholder="Enter your name" required pattern="[A-Z a-z]{}"></td></tr>
                    
                <tr><td><label>Address:</label></td><td><textarea name="address" placeholder="Address" required></textarea></td></tr>
                <tr><td><label>Age:</label></td><td><input autocomplete="off" type="Number" name="age" required pattern="[0-3]{9}"  placeholder="Enter your age" required></td></tr>
                
                <tr><td><label>Gender:</label></td><td><input type="radio" name="gender" value="male" id="gender"/>Male<input type="radio" name="gender" value="female" id="gender"/>Female</td></tr>
                <tr><td><label>Mobile Number:</label></td><td><input autocomplete="off" type="text" name="mob" placeholder="Enter mobile number " required pattern="[0-9]{10}"></td></tr>
                <tr><td><label>Email:</label></td><td><input type="email" autocomplete="off" name="email" placeholder="Enter Email" required></td></tr>
                
                <tr><td><label>User Name:</label></td><td><input type="text" autocomplete="off" name="username" placeholder="Username" required></td></tr>
                <tr><td><label>Password:</label></td><td><input type="password" name="password" placeholder="Password" required></td></tr>
                
                <tr><td></td><td><input type="Submit" name="submit" value="Registration"></td></tr>
                   
                   <!--<input type="submit" value=" submit " onClick=check()>-->
            </table>
            
        </form>
					
			</div>
			<div class="register-home animated wow slideInUp" data-wow-delay=".5s">
                            <a href="login.php">Login</a>
			</div>
		</div>
	</div>
<!-- //register -->
<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="footer-grids">
				<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".5s">
					<h3>About Us</h3>
					<p>15 billion users.<span>we offered a site for a shoping feel.<span>
					make your own computer.</span>
				.</span></p>
				</div>
				<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".6s">
					<h3>Contact Info</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i><span>muvattupuzha.</span></li>
						<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">info.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+918304076541</li>
					</ul>
				</div>
				<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".7s">
					<h3>Flickr Posts</h3>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/vector-computer-mobile-phones-colorful-applic-creative-cloud-application-icon-business-software-social-media-32452698.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/800px_COLOURBOX11074382.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/Creative_Labs_51MF0305AA002_I_Trigue_L3800_Computer_Speaker_429669.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/computermouse12.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/brand-business-cellphone-204611.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/14259a264d0a621577c22951ecd671c5.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/11.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/2.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/d255d4b1f364e00834a57d6e661d96c8.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/micorosoft_surface_dribbble.gif" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/wp2105387.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="footer-grid-left">
						<a href="login.php"><img src="images/apple-computer-keyboard-wallpaper-2.jpg" alt=" " class="img-responsive" /></a>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".8s">
					<h3>Blog Posts</h3>
					<div class="footer-grid-sub-grids">
						<div class="footer-grid-sub-grid-left">
							<a href="login.php"><img src="images/14259a264d0a621577c22951ecd671c5.jpg" alt=" " class="img-responsive" /></a>
						</div>
						<div class="footer-grid-sub-grid-right">
							<h4><a href="login.php">lighting board and mouse</a></h4>
							<p>Posted On 20/3/2019</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="footer-grid-sub-grids">
						<div class="footer-grid-sub-grid-left">
							<a href="login.php"><img src="images/Untitled (2).jpg" alt=" " class="img-responsive" /></a>
						</div>
						<div class="footer-grid-sub-grid-right">
							<h4><a href="login.php">lap offer zone</a></h4>
							<p>Posted On 25/3/2019</p>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="footer-logo animated wow slideInUp" data-wow-delay=".5s">
				<h2><a href="index.php">Best Store <span>shop anywhere</span></a></h2>
			</div>
			<div class="copy-right animated wow slideInUp" data-wow-delay=".5s">
				<p>&copy 2016 Best Store. All rights reserved | Design by <a href="">Cyber</a></p>
			</div>
		</div>
	</div>
<!-- //footer -->
</body>
</html>
